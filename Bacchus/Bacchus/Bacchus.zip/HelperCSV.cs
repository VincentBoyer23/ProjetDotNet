﻿using System;
using System.IO;
using Bacchus.Controller;


namespace Bacchus
{
    class HelperCSV
    {

        public static void saveFromFile(String FilePath, bool append)
        {

        }
    }
}
